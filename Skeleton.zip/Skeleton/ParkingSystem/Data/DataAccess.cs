﻿using System;
using ParkingSystem.Models;

namespace ParkingSystem.Data
{
	public class DataAccess
	{
		public static List<Car> Cars { get; set; } = new List<Car>();
	}
}

